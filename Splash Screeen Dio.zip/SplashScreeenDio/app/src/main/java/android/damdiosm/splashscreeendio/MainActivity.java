package android.damdiosm.splashscreeendio;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import java.text.DecimalFormat;
import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    RadioButton radioMenikah, radioSingle;
    EditText editJumlahAnak, editPenghasilan, editPTKP, editPKP, editPajak;
    Button buttonHitung;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        radioMenikah = (RadioButton)findViewById(R.id.radioMenikah);
        radioSingle = (RadioButton)findViewById(R.id.radioSingle);
        editJumlahAnak = (EditText)findViewById(R.id.editJumlahAnak);
        editPenghasilan = (EditText)findViewById(R.id.editPenghasilan);
        editPTKP = (EditText)findViewById(R.id.editPTKP);
        editPKP = (EditText)findViewById(R.id.editPKP);
        editPajak = (EditText)findViewById(R.id.editPajak);
        editPenghasilan = (EditText)findViewById(R.id.editPenghasilan);
        buttonHitung = (Button)findViewById(R.id.buttonHitung);
        buttonHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String status = "S";
                if (radioMenikah.isChecked() == true){
                    status = "M";
                }
                double anak = 0;
                if (editJumlahAnak.getText().toString().trim().equals("") == false){
                    anak = Double.parseDouble(editJumlahAnak.getText().toString());
                }
                double PTKP = 54000000;
                if (status.equals("M")){
                    PTKP = PTKP + 4500000;
                }
                PTKP = PTKP + (anak * 4500000);
                double penghasilan = 0;
                if (editPenghasilan.getText().toString().trim().equals("") == false){
                    penghasilan = Double.parseDouble(editPenghasilan.getText().toString());
                }
                double PKP = penghasilan;
                if (penghasilan > PTKP) {
                    PKP = penghasilan - PTKP;
                }
                double pajak = 0;
                if (PKP < 50000000) {
                    pajak = pajak + (PKP * 0.05);
                } else {
                    pajak = pajak + (50000000 * 0.05);
                    if (PKP < 250000000) {
                        pajak = pajak + ((PKP - 50000000) * 0.15);
                    } else {
                        pajak = pajak + (200000000 * 0.15); //sisa 250jt-50jt
                        if (PKP < 500000000) {
                            pajak = pajak + ((PKP - 250000000) * 0.25);
                        } else {
                            pajak = pajak + (250000000 * 0.25); //sisa 500jt-50jt-200 jt
                            pajak = pajak + ((PKP - 500000000) * 0.30);
                        }
                    }
                }
                NumberFormat formatter = new DecimalFormat("#,###.##");
                editPTKP.setText(formatter.format(PTKP));
                editPKP.setText(formatter.format(PKP));
                editPajak.setText(formatter.format(pajak));
            }
        });
    }
}
